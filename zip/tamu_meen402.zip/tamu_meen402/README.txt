[Description of Python Files]
Xiaochen Yan 2022.07.09




project files:
	these files require rospy and OptiTrack to operate
	these are also the deliverables for this project

1. functions.py
	includes functions that the other 2 files need
	sensor function for tracking robot locations
	control function for moving robot according to path

2. input.py
	see test_input

3. trajectory.py
	get initial coordinates from sensor function
	user input final coordinates
	create trajectories for all robots
	UPDATE 2022.07.13:
		now supports 3 robots
		can also support 4 but i assume we are doing 3 for now
		see pathtest4 update
	UPDATE 2022.07.14:
		outputs movement instructions (robot.move):
		[[[x, y], 'start'], [[x, y], time], [[x, y], end]]
	UPDATE 2022.07.26:
		takes inputs from robot.csv made by input
		see test_trajectory2

4. execute.py
	take specific robot trajectory as input
	create movement instructions by calling functions
	UPDATE 2022.07.14:
		now takes in robot.move as input (see trajectory output)




development files:
	these files are simulation versions of project files
	they do not need installation of rospy and OptiTrack
	you can use these to debug code outside of lab
	UPDATE 2022.07.20:
		changed the names to show connection to project files
		changed input method, project files not synced yet
		if you like this format i will update trajectory

1. test_input.py
	initialize robots
	save robots to csv file
	instructions are in the comments of the file

2. test_trajectory.py
	now completely automated
	takes in inputs from a csv file made by test_input
	velocity is still in test_trajectory

3. test_trajectory2.py
	update editlst to only edit in the first wait for each robot

4. test_execute.py
	simulation of execute file
	when debugging remember:
	comment out the print statements of whatever pathtest you import
	UPDATE 2022.07.20:
		updated to take inputs from test_trajectory




outdated files:
	files that i stopped updating for various reasons

1. pathgraph.py
	for visual of initial robot trajectories
	stopped updating after creation

2. pathtest2.py
	simulation of 2 robot trajectory
	un-comment the print statements for debug
	stopped updating after pathtest4

3. pathtest4.py
	simulation of 4 robot trajectory
	un-comment the print statements for debug
	UPDATE 2022.07.13:
		optimized for arbitrary number of robots
		initializing robots still need to be manually edited
	UPDATE 2022.07.14:
		see trajectory update
	stopped updating after test_trajectory