
#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseStamped
from math import radians, pi
import math
import numpy as np

from util import quaternion_to_euler
import time

# TURTLEBOT_ID = 'yellow' # might need to change this. If unsure or doesn't work, check rostopic list

# moving_cmd_topic = '/' + TURTLEBOT_ID + '/cmd_vel_mux/input/navi'
#moving_cmd_topic = '/cmd_vel_mux/input/navi'

# odom_reading_topic = '/' + TURTLEBOT_ID + '/odom/'
# odom_reading_topic = '/odom/'
#odom_reading_topic = '/vrpn_client_node/TB1/pose'

# define global function that constantly read odom reading
def listener(odom_reading_topic, ped_reading_topic=None):

	rospy.init_node('tb_control', anonymous=False)

	# topic = "/" + TURTLEBOT_ID + "/odom/"

	def turtlebot_callback(data):
		
		global cur_linear_x
		global cur_linear_y
		global cur_linear_z
		global cur_angular_x
		global cur_angular_y
		global cur_angular_z
		global cur_angular_w
		global cur_yaw
		global cur_pitch
		global cur_roll
		
		cur_linear_x = -data.pose.position.x
		cur_linear_y = data.pose.position.z
		cur_linear_z = data.pose.position.y
		
		cur_angular_x = data.pose.orientation.x
		cur_angular_y = data.pose.orientation.z
		cur_angular_z = data.pose.orientation.y
		cur_angular_w = data.pose.orientation.w
		
		# each yaw, pitch, roll is between -pi to pi
		cur_yaw, cur_pitch, cur_roll = quaternion_to_euler(cur_angular_x, cur_angular_y, cur_angular_z, cur_angular_w)
		cur_yaw_affine = cur_yaw + pi # range of [0, 2pi]
		cur_yaw = (cur_yaw_affine + pi/2) % (2*pi)
		cur_yaw = cur_yaw - pi
		
	def pedestrain_callback(data):
		global cur_ped_x
		global cur_ped_y
		
		cur_ped_x = -data.pose.position.x
		cur_ped_y = data.pose.position.z
		
	# tb_sub.unregister()
	rospy.Subscriber(ped_reading_topic, PoseStamped, pedestrain_callback)
	rospy.Subscriber(odom_reading_topic, PoseStamped, turtlebot_callback)

class simple_move():
	def __init__(self, moving_cmd_topic):
		# initiliaze
		# rospy.init_node('drawasquare', anonymous=False)

		# What to do you ctrl + c
		rospy.on_shutdown(self.shutdown)

		#TurtleBot will stop if we don't keep telling it to move.  How often should we tell it to move? 10 HZ = 1/10 s = 0.1s
		self.update_rate = 10
		self.r = rospy.Rate(self.update_rate)

		self.cmd_vel = rospy.Publisher(moving_cmd_topic, Twist, queue_size=10)

	def shutdown(self):
		# stop turtlebot
		shut_down_cmd = Twist()
		shut_down_cmd.linear.x = 0
		shut_down_cmd.angular.z = 0
		self.cmd_vel.publish(shut_down_cmd)
		# rospy.sleep(1)
		# sub.unregister()
		# rospy.loginfo("Stop Moving")


	def go_straight(self, time=None, speed=0.2, distance=None):
		# proportional control term
		p1 = 3

		if distance:
			desired_x = cur_linear_x + math.cos(cur_yaw) * distance
			desired_y = cur_linear_y + math.sin(cur_yaw) * distance

			# print("desired_x: {0} desired_y: {1}".format(desired_x, desired_y))

			go_straight_cmd = Twist()
			go_straight_cmd.linear.x = speed
			go_straight_cmd.angular.z = 0


			# rospy.loginfo("go to {0} at speed {1} def/s".format(distance, speed))

			x_err, y_err = abs(desired_x - cur_linear_x), abs(desired_y - cur_linear_y)

			# while the distance is less than some threshold
			while abs(desired_x - cur_linear_x) > 0.1 or abs(desired_y - cur_linear_y) > 0.1:
				print("x and y errors are as foollows: ", x_err, y_err)
				print("tb x: {0} y: {1}".format(cur_linear_x, cur_linear_y))

				if abs(desired_x - cur_linear_x) < 0.3 and abs(desired_y - cur_linear_y) < 0.3:
					if speed > 0:
						go_straight_cmd.linear.x = max(speed * abs(desired_x - cur_linear_x) * p1, 0.2)
					else:
						go_straight_cmd.linear.x = min(speed * abs(desired_x - cur_linear_x) * p1, -0.2)
				self.cmd_vel.publish(go_straight_cmd)
				self.r.sleep()
				x_err, y_err = abs(desired_x - cur_linear_x), abs(desired_y - cur_linear_y)


		elif time:
			# rospy.loginfo("go for {0} s at speed {1} m/s".format(time, speed))
			go_straight_cmd = Twist()
			go_straight_cmd.linear.x = speed
			go_straight_cmd.angular.z = 0

			for x in range(0,int(time*self.update_rate)):
				self.cmd_vel.publish(go_straight_cmd)
				self.r.sleep()
		# go forever
		elif time is None and distance is None:
			go_straight_cmd = Twist()
			go_straight_cmd.linear.x = speed
			go_straight_cmd.angular.z = 0
			for x in range(0,999*self.update_rate):
				self.cmd_vel.publish(go_straight_cmd)
				self.r.sleep()


	def turn(self, time=None, speed=0.4, angle=None, yaw_coor=None):
		# counterclockwise is always increasing, and clockwise is always decreasing
		# starting z orientation angle is always 0,
		# and the reverse (pi or 180 degree) z is 1/-1 depends on which direction it moves
		# if move counterclockwise, then 0 -> pi -> -pi -> 0 complete one loop
		# if move clockwise, then 0 -> -pi -> pi -> 0 complete one loop

		if time:
			turn_cmd = Twist()
			turn_cmd.linear.x = 0
			turn_cmd.angular.z = speed
			rospy.loginfo("turn left for {0} s at speed {1} def/s".format(time, speed))
			for x in range(0,time*self.update_rate):
				self.cmd_vel.publish(turn_cmd)
				self.r.sleep()
				print("current yaw: ", cur_yaw)
		elif angle:
			if angle > 180 or angle < -180:
				raise Exception("angle must be smaller than 180 or greater than -180")

			starting_yaw = cur_yaw
			ending_yaw = radians(angle) + starting_yaw

			# handle the case where from positive to negative or from negative to positive
			if ending_yaw > pi:
				ending_yaw = pi-ending_yaw
			elif ending_yaw < -pi:
				ending_yaw = 2*pi+ending_yaw
			yaw_coor = ending_yaw
			rospy.loginfo("turn for {0} degree at speed {1} rad/s".format(angle, speed))

		# because z_coor could be 0
		if yaw_coor is not None:
			if yaw_coor > pi or yaw_coor < -pi:
				raise Exception("yaw_coor must be smaller than pi or greater than -pi")

			turn_cmd = Twist()
			turn_cmd.angular.z = speed

			print("starting to turn")



			error = min([abs(cur_yaw - yaw_coor), abs(cur_yaw - yaw_coor-2*pi), abs(cur_yaw - yaw_coor+2*pi)])
			while error > 0.02:
				if error < 0.2:
					turn_cmd.angular.z = speed/2

				print("turning, with error ", abs(cur_yaw - yaw_coor))
				print("cur_yaw ", cur_yaw)
				print("yaw_coor ", yaw_coor)
				abs(cur_yaw - yaw_coor)
				self.cmd_vel.publish(turn_cmd)
				self.r.sleep()
				error = abs(cur_yaw - yaw_coor)



			turn_cmd.angular.z = 0
			self.cmd_vel.publish(turn_cmd)


	def curve_left(self, time, lin_speed=0.2, ang_speed=20):
		curve_left_cmd = Twist()
		curve_left_cmd.linear.x = lin_speed
		curve_left_cmd.angular.z = radians(ang_speed); # convert 45 deg/s to radians/s
		rospy.loginfo("curve left for {0} s at linear speed {1} m/s and angular speed {2} def/s".format(time, lin_speed, ang_speed))
		for x in range(0,time*self.update_rate):
			self.cmd_vel.publish(curve_left_cmd)
			self.r.sleep()


	def curve_right(self, time, lin_speed=0.2, ang_speed=20):
		curve_right_cmd = Twist()
		curve_right_cmd.linear.x = lin_speed
		curve_right_cmd.angular.z = -radians(ang_speed); # convert 45 deg/s to radians/s
		rospy.loginfo("curve right for {0} s at linear speed {1} m/s and angular speed {2} def/s".format(time, lin_speed, ang_speed))
		for x in range(0,time*self.update_rate):
			self.cmd_vel.publish(curve_right_cmd)
			self.r.sleep()


	def follow(self, trail, stopping=True, tol = 0.1, Kd=0.5, Kp=0.8, speed=0.1):
		start_error = (cur_linear_x-trail.x_pos[0])**2+(cur_linear_y-trail.y_pos[0])**2
		control_cmd = Twist()		
		print('current position: '+str(cur_linear_x)+', '+str(cur_linear_y))
		print('path_start: '+str(trail.x_pos[0])+', '+str(trail.y_pos[0]))
		print('path: ' + str(trail.y_pos))
		if start_error > tol**2:
			print('Path does not start at robot location')
		end_error = (cur_linear_x-trail.x_pos[-1])**2+(cur_linear_y-trail.y_pos[-1])**2
		current_path_x = trail.x_pos[0]
		current_path_y = trail.y_pos[0]
		current_path_ind = 0
		print('Tans: '+str(trail.y_tan[0])+', '+str(trail.x_tan[0]))
		self.turn(yaw_coor = math.atan2(trail.y_tan[0], trail.x_tan[0]),speed=-0.4)
		x_hist = []
		y_hist = []
		x_hist.append(cur_linear_x)		
		current_vel_yaw=0
		y_hist.append(cur_linear_y)
		time_start = time.time()
		while end_error > tol**2:			
			if ((trail.x_pos[current_path_ind+3]-cur_ped_x)**2+(trail.y_pos[current_path_ind+3]-cur_ped_y)**2)**0.5 < 0.5 and stopping:
				self.r.sleep()
				return False			
			print('current path yaw: '+str(trail.yaw[current_path_ind]))	
			print('current path position: '+str(trail.x_pos[current_path_ind])+', '+str(trail.y_pos[current_path_ind]))
			print('current yaw: '+str(cur_yaw))
			print('current position: '+str(cur_linear_x)+', '+str(cur_linear_y))
			end_error = (cur_linear_x-trail.x_pos[-1])**2+(cur_linear_y-trail.y_pos[-1])**2			
			if current_path_ind < 5:		
				for i in range(0, 10):
					if (cur_linear_x-trail.x_pos[i])**2+(cur_linear_y-trail.y_pos[i])**2 < (cur_linear_x-current_path_x)**2+(cur_linear_y-current_path_y)**2:
						current_path_x = trail.x_pos[i]
						current_path_y = trail.y_pos[i]
						current_path_ind = i
			elif current_path_ind > len(trail.x_pos)-5:
				for i in range(len(trail.x_pos)-5, len(trail.x_pos)):
					if (cur_linear_x-trail.x_pos[i])**2+(cur_linear_y-trail.y_pos[i])**2 < (cur_linear_x-current_path_x)**2+(cur_linear_y-current_path_y)**2:
						current_path_x = trail.x_pos[i]
						current_path_y = trail.y_pos[i]
						current_path_ind = i		
			else:
				for i in range(current_path_ind-5, current_path_ind+5):
					if (cur_linear_x-trail.x_pos[i])**2+(cur_linear_y-trail.y_pos[i])**2 < (cur_linear_x-current_path_x)**2+(cur_linear_y-current_path_y)**2:
						current_path_x = trail.x_pos[i]
						current_path_y = trail.y_pos[i]
						current_path_ind = i
			x_hist.append(cur_linear_x)		
			y_hist.append(cur_linear_y)
			if len(x_hist)>2:
				x_hist.pop(0)
				y_hist.pop(0)
			if x_hist[0]!=x_hist[1]:	
				current_vel_yaw = math.atan2(y_hist[1]-y_hist[0], x_hist[1]-x_hist[0])
			#current_vel_yaw = cur_yaw
			err_pos = ((cur_linear_x-current_path_x)*trail.y_tan[current_path_ind] - (cur_linear_y-current_path_y)*trail.x_tan[current_path_ind])
			if current_path_ind > 2:
				err_yaw = (trail.yaw[current_path_ind] - current_vel_yaw)
			else:
				err_yaw=0.0
			print('yaw_error = '+str(err_yaw))
			if abs(err_pos) > 5:
				print('Too much positional deviation.')
				break
			#if abs(err_yaw) > 1.5:
			#	print('Too much orientational deviation.')
			#	break
			d_control = Kd * err_yaw
			p_control = Kp * err_pos
			control_cmd.angular.z = d_control+p_control
			control_cmd.linear.x = speed
			self.cmd_vel.publish(control_cmd)


			if x_hist[0]!=x_hist[1]:
				print('current path yaw: '+str(trail.yaw[current_path_ind]))
				print('current path position: '+str(trail.x_pos[current_path_ind])+', '+str(trail.y_pos[current_path_ind]))
				print('current yaw: '+str(cur_yaw))
				print('current position: '+str(cur_linear_x)+', '+str(cur_linear_y))
				
		self.r.sleep()
		return time.time()-time_start


class path():
	def __init__(self, x_func, y_func, start, end, n_points, x_vel_func=None, y_vel_func=None, cur_func = None):
		t = np.linspace(start, end, n_points)
		self.points=np.zeros(n_points)
		x = np.zeros(n_points)
		y = np.zeros(n_points)
		for i in range(n_points):
			x[i] = x_func(t[i])
			y[i] = y_func(t[i])
		x_vel = np.zeros(n_points)
		y_vel = np.zeros(n_points)
		path_yaw = np.zeros(n_points)
		for i in range(n_points):
			if x_vel_func:
				x_vel[i] = x_vel_func(t[i])
				y_vel[i] = y_vel_func(t[i])
			elif i == 0:				
				x_vel[i] = x[i+1] - x[i]
				y_vel[i] = y[i+1] - y[i]
				tan_len=(x_vel[i]**2+y_vel[i]**2)**0.5				
				x_vel[i] = x_vel[i]/tan_len
				y_vel[i] = y_vel[i]/tan_len
			elif i == n_points-1:
				x_vel[i] = x[i] - x[i-1]
				y_vel[i] = y[i] - y[i-1]
				tan_len=(x_vel[i]**2+y_vel[i]**2)**0.5				
				x_vel[i] = x_vel[i]/tan_len
				y_vel[i] = y_vel[i]/tan_len
			else:
				x_vel[i] = (x[i+1] - x[i-1])/2
				y_vel[i] = (y[i+1] - y[i-1])/2
				tan_len=(x_vel[i]**2+y_vel[i]**2)**0.5				
				x_vel[i] = x_vel[i]/tan_len
				y_vel[i] = y_vel[i]/tan_len
			path_yaw[i] = math.atan2(y_vel[i], x_vel[i])
		self.x_pos = x
		self.y_pos = y
		self.x_tan = x_vel
		self.y_tan = y_vel
		self.yaw = path_yaw
		if cur_func:
			cur = np.zeros(n_points)
			for i in range(n_points):
				cur[i] = cur_func(t[i])
			self.curve = cur

def line(start, end):
	def x(t):
		return t
	def y(t):
		return ((end[1]-start[1])/(end[0]-start[0]))*(t-start[0])+start[1]
	return path(x, y, start[0], end[0], 100)

def circular(start, center, angle):
	def x(t):
		return (math.sqrt((start[0]-center[0])**2+(start[1]-center[1])**2)*math.cos(t) + center[0])
	def y(t):
		return (math.sqrt((start[0]-center[0])**2+(start[1]-center[1])**2)*math.sin(t) + center[1])
	return path(x, y, math.atan2((start[1]-center[1]),(start[0]-center[0])), angle, 100)

def calibrate_speed(speeds):
	turtlebot = simple_move()
	current_x = cur_linear_x
	current_y = cur_linear_y
	goal = (cur_linear_x, cur_linear_y+3)
	vels = []
	for i in range(5):
		def x(t):
			return t
		def y(t):
			return ((goal[1]-current_y)/(goal[0]-current_x))*(t-current_x)+current_y
		straight = path(x, y, current_x, goal[0], 100)
		travel_time = turtlebot.follow(straight,0.2,1.0,4,speeds[i], False)
		vels.append(3/travel_time)
	prods = []
	sp_sqs = []
	for i in range(len(speeds)):
		prods.append(speeds[i]*vels[i])
		sp_sqs.append(speeds[i]**2)
	m = (len(speeds)*sum(prods)-sum(speeds)*sum(vels))/(len(speeds)*sum(sp_sqs)-sum(speeds)**2)
		 
	print('Measured velocities are: '+str(vels)+' for ' + str(speeds))
	print('The average constant of proportionality is '+ str(m))


