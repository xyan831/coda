import test_trajectory as tj

# get robot trajectory
#lst = tj.robot_org[0].move
#lst = tj.robot_org[1].move
#lst = tj.robot_org[2].move
lst = tj.robot_org[3].move

# create movement instruction
head = lst[0]
for i in range(1, len(lst)):
	# move straight line
	print('line: ', head[0], lst[i][0])
	if (lst[i][1] != 'end'):
		# wait for some time
		print('wait: ', lst[i][0], lst[i][1])
	head = lst[i]
