# import module
import numpy as np
import pandas as pd
from math import sqrt
import sys

# find distance between 2 points
def DM(r):
	d = sqrt((r[0][1]-r[0][0])**2 + (r[1][1]-r[1][0])**2)
	return d

# find if point (c) is on line segment (a-b)
def OL(a, b, c):
	cp = (c[1]-a[1])*(b[0]-a[0]) - (c[0]-a[0])*(b[1]-a[1]) # cross product
	dp = (c[0]-a[0])*(b[0]-a[0]) + (c[1]-a[1])*(b[1]-a[1]) # dot product
	ab2 = (b[0]-a[0])**2 + (b[1]-a[1])**2 # squared length
	if (abs(cp)>sys.float_info.epsilon):
		return False
	if (dp<0):
		return False
	if (dp>ab2):
		return False
	return True

# find intersecting point of 2 lines
def IP(r1, r2):
	xdiff = [r1[0][0]-r1[1][0], r2[0][0]-r2[1][0]]
	ydiff = [r1[0][1]-r1[1][1], r2[0][1]-r2[1][1]]
	def det(a, b):
		return a[0]*b[1] - a[1]*b[0]
	div = det(xdiff, ydiff)
	if div==0:
		return None
	d = [det(*r1), det(*r2)]
	x = det(d, xdiff)/div
	y = det(d, ydiff)/div
	if OL(r1[0], r1[1], [x, y]) and OL(r2[0], r2[1], [x, y]):
		return [x, y]
	else:
		return None

# check if point in intersection range
def checkIn(point, cen, rad):
	if point != None:
		if (point[0]-cen[0])**2+(point[1]-cen[1])**2<=(rad)**2:
			return True
		else:
			return False

# robot information
class robot:
	def __init__(self, name, initial, final, vel=1):
		self.name = name
		self.line = [initial, final]
		self.rang = int(DM([initial, final])*(1/vel))
		self.lst = self.getlst(initial, final, self.rang)
		self.cur = None
		self.wait = []
		self.move = self.getmove()
	# 1 list of both x and y coordinates
	def getlst(self, initial, final, rang):
		xlst = np.linspace(initial[0], final[0], rang)
		ylst = np.linspace(initial[1], final[1], rang)
		lst = []
		for i in range(rang):
			lst.append([xlst[i], ylst[i]])
		return lst
	def editlst(self): # only edits the first wait in
		lst = [[self.wait[0], 1]]
		j = 0
		for i in range(1, len(self.wait)):
			if self.wait[i]=='continue':
				lst[j][1] += 1
			else:
				j+=1
				lst.append([self.wait[i], 1])
		# edit first wait
		idx = self.lst.index(lst[0][0])-1
		self.lst[idx:idx] = [self.lst[idx]]*lst[0][1]
		# update wait list and range
		self.wait = []
		self.rang = len(self.lst)
	# get movement intructions
	def getmove(self):
		counts = []
		for i in self.lst:
			count = 0
			for j in self.lst:
				if i==j:
					count += 1
			if count>1 and ([i, count] not in counts):
				counts.append([i, count])
		return [[self.lst[0], 'start']]+counts+[[self.lst[-1], 'end']]

# simulation of multiple robots
def simulation(robot, cross):
	# minimum distance between centers of 2 robots
	mindis = 6/5
	for i in range(robot[0].rang):
		# update previous crossing robots
		for j in range(len(cross)):
			cross[j][2] = cross[j][1]
		# check each intersection
		for j in range(len(cross)):
			# robot crossing instructions
			checkall = []
			for k in robot:
				# update current position
				k.cur = k.lst[i] if (i<k.rang) else None
				# check each robot for crossing
				check = checkIn(k.cur, cross[j][0], mindis/2)
				if check==True:
					# update current crossing to robot 1
					if (cross[j][1]==None) or (cross[j][1]==k.name):
						cross[j][1] = k.name
					# update collision information
					else:
						if cross[j][2]==None:
							k.wait.append(k.cur)
						else:
							k.wait.append('continue')
				checkall.append(check)
			# if no robot is currently crossing
			if (True not in checkall):
				cross[j][1] = None

# initialize robots: get input from csv
vel = 0.1

robot_org = []
rdf = pd.read_csv('robot.csv')
for i in range(len(rdf)):
	name = rdf['name'][i]
	xi = rdf['xi'][i]
	yi = rdf['yi'][i]
	xf = rdf['xf'][i]
	yf = rdf['yf'][i]
	r = robot(name, [xi, yi], [xf, yf], vel)
	robot_org.append(r)

# find possible intersections (assume every 2 lines only have 1)
intersect = []
for i in range(len(robot_org)):
	for j in range(i+1, len(robot_org)):
		point = IP(robot_org[i].line, robot_org[j].line)
		intersect.append(point)

# valid intersections append to cross
cross = []
for point in intersect:
	if point!=None and [point, None, None] not in cross:
		# point, current crossing robot, previous crossing robot
		cross.append([point, None, None])

# get hierarchy of robots
robot = robot_org
for i in range(0, len(robot)-2):
	for j in range(0, len(robot)-i-1):
		if (robot[j].rang<robot[j+1].rang):
			temp = robot[j]
			robot[j] = robot[j+1]
			robot[j+1] = temp

# run simulation based on hierarchy
simulation(robot, cross)
'''
# print for debug
for i in robot_org:
	print(i.name, i.wait)
'''
# edit trajectory based on collision info
for i in robot:
	i.editlst() if (i.wait!=[]) else None
'''
# print for debug
for i in robot_org:
	print(i.name, i.wait)
'''
# loop simulations
checkwait = [i.wait==[] for i in robot_org]
while (False in checkwait):
	robot = robot_org
	for i in range(0, len(robot)-2):
		for j in range(0, len(robot)-i-1):
			if (robot[j].rang<robot[j+1].rang):
				temp = robot[j]
				robot[j] = robot[j+1]
				robot[j+1] = temp
	simulation(robot, cross)
	for i in robot:
		i.editlst() if (i.wait!=[]) else None
	'''
	# print for debug
	for i in robot_org:
		print(i.name, i.wait)
	'''
	# random comment

# create move instructions
for i in robot_org:
	i.move = i.getmove()

#print('done')

#output
'''
for i in robot_org:
	print(i.move)
'''
