# import module
import pandas as pd

# initializing robots as lists

# order of variables:
# ['name', xi, yi, xf, yf]

# 'name' = name of robot
# (xi, yi) = initial coordinates
# (xf, yf) = final coordinates

r1 = ['r1', 0, 5, 10, 5]
r2 = ['r2', 5, 0, 5, 10]
r3 = ['r3', 10, 15, 20, 15]
r4 = ['r4', 15, 10, 15, 20]

# put all robot variables in this list
r = [r1, r2, r3, r4]

# creates dataframe and saves as csv file (do not change)
r = pd.DataFrame(r, columns=['name', 'xi', 'yi', 'xf', 'yf'])
r.to_csv('robot.csv')
