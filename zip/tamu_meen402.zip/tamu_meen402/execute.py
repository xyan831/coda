import time
import functions as fn
import trajectory as tj

# TURTLEBOT_ID = 'yellow' # might need to change this. If unsure or doesn't work, check rostopic list
# moving_cmd_topic = '/' + TURTLEBOT_ID + '/cmd_vel_mux/input/navi'
moving_cmd_topic = '/cmd_vel_mux/input/navi'
# odom_reading_topic = '/' + TURTLEBOT_ID + '/odom/'
# odom_reading_topic = '/odom/'
odom_reading_topic = '/vrpn_client_node/TB1/pose'

cur_linear_x = None
cur_linear_y = None

# get robot trajectory
#lst = tj.robot_org[0].move
#lst = tj.robot_org[1].move
#lst = tj.robot_org[2].move
lst = tj.robot_org[3].move

# turtlebot simple move class
turtlebot = fn.simple_move(moving_cmd_topic)

# create movement instruction
head = lst[0]
for i in range(1, len(lst)):
	# move straight line
	#print('line: ', head[0], lst[i][0])
	straight = fn.line(head[0], lst[i][0])
	turtlebot.follow(straight, False)
	if (lst[i][1] != 'end'):
		# wait for some time
		#print('wait: ', lst[i][0], lst[i][1])
		time.sleep(lst[i][1]) #????
	head = lst[i]

# shutdown turtlebot
turtlebot.shutdown()
